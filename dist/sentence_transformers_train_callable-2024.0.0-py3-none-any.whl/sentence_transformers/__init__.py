# __init__.py

from importlib import resources

__version__ = "1.0.0"